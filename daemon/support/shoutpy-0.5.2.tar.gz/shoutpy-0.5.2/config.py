# Local configuration for shoutpy
# Daniel Holth <dholth@fastmail.fm>, 2004
# This one is for gentoo.

libraries = ["shout"]
libraries.extend(("boost_python",))
# libraries.extend(("boost_python-gcc-mt-1_31",)) # this name may also work for you

library_dirs = []

include_dirs = []
