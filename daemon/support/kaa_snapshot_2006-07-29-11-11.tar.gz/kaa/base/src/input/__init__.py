import lirc
