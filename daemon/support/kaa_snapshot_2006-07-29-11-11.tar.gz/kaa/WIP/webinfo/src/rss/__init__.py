__all__ = ['RssGrabber']

from rss import RssGrabber
