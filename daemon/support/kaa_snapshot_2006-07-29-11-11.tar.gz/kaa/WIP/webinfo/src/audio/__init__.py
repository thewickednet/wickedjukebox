__all__ = ['CDCoverGrabber', 'FreedbGrabber']

from freedb import FreedbGrabber
from cdcover import CDCoverGrabber