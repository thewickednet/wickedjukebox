#include "evas.h"
int engine_buffer_setup(Evas_PyObject *o, PyObject *kwargs);

