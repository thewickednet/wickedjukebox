PyObject *Evas_Object_PyObject_image_file_set(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_file_get(Evas_Object_PyObject *, PyObject *);

PyObject *Evas_Object_PyObject_image_fill_set(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_fill_get(Evas_Object_PyObject *, PyObject *);

PyObject *Evas_Object_PyObject_image_border_set(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_border_get(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_border_center_fill_set(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_border_center_fill_get(Evas_Object_PyObject *, PyObject *);

PyObject *Evas_Object_PyObject_image_size_set(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_size_get(Evas_Object_PyObject *, PyObject *);

PyObject *Evas_Object_PyObject_image_alpha_set(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_alpha_get(Evas_Object_PyObject *, PyObject *);

PyObject *Evas_Object_PyObject_image_smooth_scale_set(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_smooth_scale_get(Evas_Object_PyObject *, PyObject *);

PyObject *Evas_Object_PyObject_image_data_set(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_data_get(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_data_update_add(Evas_Object_PyObject *, PyObject *);

PyObject *Evas_Object_PyObject_image_load_error_get(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_reload(Evas_Object_PyObject *, PyObject *);

PyObject *Evas_Object_PyObject_image_pixels_dirty_set(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_pixels_dirty_get(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_image_pixels_import(Evas_Object_PyObject *, PyObject *);
