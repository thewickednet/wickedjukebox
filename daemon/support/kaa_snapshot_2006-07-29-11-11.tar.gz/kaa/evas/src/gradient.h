PyObject *Evas_Object_PyObject_gradient_color_add(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_gradient_colors_clear(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_gradient_angle_set(Evas_Object_PyObject *, PyObject *);
PyObject *Evas_Object_PyObject_gradient_angle_get(Evas_Object_PyObject *, PyObject *);
