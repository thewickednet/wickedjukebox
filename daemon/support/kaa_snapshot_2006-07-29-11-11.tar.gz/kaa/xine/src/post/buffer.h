#include <xine.h>
#include <xine/xineutils.h>
#include <xine/post.h>

extern plugin_info_t xine_buffer_plugin_info[];

