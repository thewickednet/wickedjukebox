GERMANY = [
    ('arte-tv.com', ( 60, ),  ('arte', )),
    ('zdf.de',      (118,),   ('ZDF',))
    ]

ALL_CHANNELS = GERMANY
