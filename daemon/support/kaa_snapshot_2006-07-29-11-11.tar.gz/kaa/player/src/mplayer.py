import os, re, string, tempfile, time, stat, threading, md5, struct
from kaa import notifier, display, shm
import kaa
import kaa.utils
from base import *

# 0 = none, 1 = interesting lines, 2 = everything, 3 = everything + status, 
# 4 = everything + status + run through gdb
DEBUG=0

BUFFER_UNLOCKED = 0x10
BUFFER_LOCKED = 0x20


# A cache holding values specific to an MPlayer executable (version,
# filter list, video/audio driver list, input keylist).  This dict is
# keyed on the full path of the MPlayer binary.
_cache = {}

def _get_mplayer_info(path, callback = None, mtime = None):
    """
    Fetches info about the given MPlayer executable.  If the values are
    cached and the cache is fresh, it returns a dict immediately.  If it
    needs to load MPlayer to fetch the values and callback is specified,
    it does so in a thread, and calls callback with the results on
    completion.  If callback is None and no information is in the cache,
    this function blocks.

    If 'mtime' is not None, it means we've called ourself as a thread.
    """

    if not mtime:
        # Fetch the mtime of the binary
        try:
            mtime = os.stat(path)[stat.ST_MTIME]
        except (OSError, TypeError):
            return None

        if path in _cache and _cache[path]["mtime"] == mtime:
            # Cache isn't stale, so return that.
            return _cache[path]

        if callback:
            # We need to run MPlayer to get these values.  Create a signal, call
            # ourself as a thread, and return the signal back to the caller.
            thread = notifier.Thread(_get_mplayer_info, path, None, mtime)
            # Thread class ensures the callbacks get invoked in the main thread.
            thread.signals["completed"].connect(callback)
            thread.signals["exception"].connect(callback)
            thread.start()
            return None

    # At this point we're running in a thread.

    info = { 
        "version": None, 
        "mtime": mtime,
        "video_filters": {},
        "video_drivers": {},
        "audio_filters": {},
        "audio_drivers": {},
        "keylist": []
    }

    regexps = (
        ("video_filters", "-vf help", "\s*(\w+)\s+:\s+(.*)"),
        ("video_drivers", "-vo help", "\s*(\w+)\s+(.*)"),
        ("audio_filters", "-af help", "\s*(\w+)\s+:\s+(.*)"),
        ("audio_drivers", "-ao help", "\s*(\w+)\s+(.*)"),
        ("keylist", "-input keylist", "^(\w+)$"),
    )

    for key, args, regexp in regexps:
        for line in os.popen("%s %s" % (path, args)):
            # Check version
            if line.startswith("MPlayer "):
                info["version"] = line.split()[1]

            # Check regexp
            m = re.match(regexp, line.strip())
            if not m:
                continue

            if len(m.groups()) == 2:
                info[key][m.group(1)] = m.group(2)
            else:
                info[key].append(m.group(1))
 
    _cache[path] = info
    return info       



class MPlayerError(Exception):
    pass

class MPlayerExitError(MPlayerError):
    pass

class MPlayer(MediaPlayer):

    PATH = None
    _instance_count = 0

    RE_STATUS = re.compile("V:\s*([\d+\.]+)|A:\s*([\d+\.]+)\s\W")

    def __init__(self):
        super(MPlayer, self).__init__()
        self._mp_cmd = MPlayer.PATH
        if not self._mp_cmd:
            self._mp_cmd = kaa.utils.which("mplayer")

        if not self._mp_cmd:
            raise MPlayerError, "No MPlayer executable found in PATH"

        self._debug = DEBUG
        # Used for vf_overlay and vf_outbuf
        self._instance_id = "%d-%d" % (os.getpid(), MPlayer._instance_count)
        MPlayer._instance_count += 1

        # Size of the window as reported by MPlayer (aspect-corrected)
        self._vo_size = None 
        self._process = None
        self._state = STATE_NOT_RUNNING
        self._state_data = None
        self._overlay_shmem = None
        self._outbuf_shmem = None
        self._file = None
        self._file_args = []

        self._file_info = {}
        self._position = 0.0
        self._filters_pre = []
        self._filters_add = []
        self._last_line = None
        
        self.signals.update({
            "output": notifier.Signal(),
        })

        self._mp_info = _get_mplayer_info(self._mp_cmd, self._handle_mp_info)
        self._check_new_frame_timer = notifier.WeakTimer(self._check_new_frame)
        self._cur_outbuf_mode = [True, False, None] # vo, shmem, size


    def _spawn(self, args, hook_notifier = True):
        if self._debug > 0:
            print "Spawn:", self._mp_cmd, args

        if self._debug > 3:
            # With debug > 3, run mplayer through gdb.
            self._process = notifier.Process("gdb")
            self._process.start(self._mp_cmd)
            self._process.write("run %s\n" % args)
        else:
            self._process = notifier.Process(self._mp_cmd)
            self._process.start(args)

        if hook_notifier:
            self._process.signals["stdout"].connect_weak(self._handle_line)
            self._process.signals["stderr"].connect_weak(self._handle_line)
            self._process.signals["completed"].connect_weak(self._exited)
            self._process.set_stop_command(notifier.WeakCallback(self._end_child))
        return self._process
    

    def _make_dummy_input_config(self):
        """
        There is no way to make MPlayer ignore keys from the X11 window.  So
        this hack makes a temp input file that maps all keys to a dummy (and
        non-existent) command which causes MPlayer not to react to any key
        presses, allowing us to implement our own handlers.  The temp file is
        deleted once MPlayer has read it.
        """
        keys = filter(lambda x: x not in string.whitespace, string.printable)
        keys = list(keys) + self._mp_info["keylist"]
        fp, filename = tempfile.mkstemp()
        for key in keys:
            os.write(fp, "%s noop\n" % key)
        os.close(fp)
        return filename

    def _handle_mp_info(self, info):
        if isinstance(info, Exception):
            self._state = STATE_NOT_RUNNING
            # TODO: handle me
            raise info
        self._mp_info = info
        if self._state_data:
            file, args = self._state_data
            self._state_data = None
            self._start(file, args)


    def _handle_line(self, line):
        if self._debug:
            if re.search("@@@|outbuf|overlay", line, re.I) and self._debug == 1:
                print line
            elif line[:2] not in ("A:", "V:") and self._debug == 2:
                print line
            elif self._debug == 3:
                print line

        if line.startswith("V:") or line.startswith("A:"):
            m = MPlayer.RE_STATUS.search(line)
            if m:
                old_pos = self._position
                self._position = float((m.group(1) or m.group(2)).replace(",", "."))
                if self._position - old_pos < 0 or self._position - old_pos > 1:
                    self.signals["seek"].emit(self._position)

                # XXX this logic won't work with seek-while-paused patch; state
                # will be "playing" after a seek.
                if self._state == STATE_PAUSED:
                    self.signals["pause_toggle"].emit()
                if self._state not in (STATE_PAUSED, STATE_PLAYING):
                    self.set_frame_output_mode()
                    self._state = STATE_PLAYING
                    self.signals["start"].emit()
                    self.signals["stream_changed"].emit()
                elif self._state != STATE_PLAYING:
                    self._state = STATE_PLAYING
                    self.signals["play"].emit()

        elif line.startswith("  =====  PAUSE"):
            self._state = STATE_PAUSED
            self.signals["pause_toggle"].emit()
            self.signals["pause"].emit()
            
        elif line.startswith("ID_") and line.find("=") != -1:
            attr, value = line.split("=")
            attr = attr[3:]
            info = { "VIDEO_FORMAT": ("vfourcc", str),
                     "VIDEO_BITRATE": ("vbitrate", int),
                     "VIDEO_WIDTH": ("width", int),
                     "VIDEO_HEIGHT": ("height", int),
                     "VIDEO_FPS": ("fps", float),
                     "VIDEO_ASPECT": ("aspect", float),
                     "AUDIO_FORMAT": ("afourcc", str),
                     "AUDIO_CODEC": ("acodec", str),
                     "AUDIO_BITRATE": ("abitrate", int),
                     "LENGTH": ("length", float),
                     "FILENAME": ("filename", str) }
            if attr in info:
                self._file_info[info[attr][0]] = info[attr][1](value)

        elif line.startswith("Movie-Aspect"):
            aspect = line[16:].split(":")[0].replace(",", ".")
            if aspect[0].isdigit():
                self._file_info["aspect"] = float(aspect)

        elif line.startswith("VO:"):
            m = re.search("=> (\d+)x(\d+)", line)
            if m:
                self._vo_size = vo_w, vo_h = int(m.group(1)), int(m.group(2))
                if self._window:
                    self._window.resize(self._vo_size)
                if "aspect" not in self._file_info or self._file_info["aspect"] == 0:
                    # No aspect defined, so base it on vo size.
                    self._file_info["aspect"] = vo_w / float(vo_h)

        elif line.startswith("overlay:") and line.find("reusing") == -1:
            m = re.search("(\d+)x(\d+)", line)
            if m:
                width, height = int(m.group(1)), int(m.group(2))
                try:
                    if self._overlay_shmem:
                        self._overlay_shmem.detach()
                except shm.error:
                    pass
                self._overlay_shmem = shm.memory(shm.getshmid(self._get_overlay_shm_key()))
                self._overlay_shmem.attach()

                self.signals["osd_configure"].emit(width, height, self._overlay_shmem.addr + 16,
                                                   width, height)

        elif line.startswith("outbuf:") and line.find("shmem key") != -1:
            try:
                if self._outbuf_shmem:
                    self._outbuf_shmem.detach()
            except shm.error:
                pass
            self._outbuf_shmem = shm.memory(shm.getshmid(self._get_outbuf_shm_key()))
            self._outbuf_shmem.attach()
            self.set_frame_output_mode()  # Sync

        elif line.startswith("EOF code"):
            if self._state in (STATE_PLAYING, STATE_PAUSED):
                self.signals["end"].emit()
                self._state = STATE_IDLE

        elif line.startswith("Parsing input"):
            # Delete the temporary key input file.
            file = line[line.find("file")+5:]
            os.unlink(file)

        #elif line.startswith("File not found"):
        #    file = line[line.find(":")+2:]
        #    raise IOError, (2, "No such file or directory: %s" % file)

        elif line.startswith("FATAL:"):
            raise MPlayerError, line.strip()

        elif self._debug > 3 and line.startswith("Program received signal SIGSEGV"):
            # Mplayer crashed, issue backtrace.
            self._process.write("thread apply all bt\n")

        if line.strip():
            self.signals["output"].emit(line)
            self._last_line = line


    def _get_overlay_shm_key(self):
        name = "mplayer-overlay.%s" % self._instance_id
        return int(md5.md5(name).hexdigest()[:7], 16)

    def _get_outbuf_shm_key(self):
        name = "mplayer-outbuf.%s" % self._instance_id
        return int(md5.md5(name).hexdigest()[:7], 16)


    def _start(self, file, user_args = None):
        assert(self._mp_info)

        keyfile = self._make_dummy_input_config()

        filters = self._filters_pre[:]
        filters += ["outbuf=%s:yv12" % self._get_outbuf_shm_key()]

        # FIXME: hardcoded
        #self._size = 800, 600
        #self._size = 854, 640
        #self._size = 640, 480

        if self._size:
            w, h = self._size
            filters += ["scale=%d:-2" % w, "expand=%d:%d" % (w, h), "dsize=%d:%d" % (w,h) ]

        args = "-v -slave -osdlevel 0 -nolirc -nojoystick -nomouseinput " \
               "-nodouble -fixed-vo -identify -framedrop -idle "

        filters += self._filters_add
        if not self._size:
            filters += ["expand=:::::4/3"]
        filters += ["overlay=%s" % self._get_overlay_shm_key()]

        if filters:
            args += "-vf %s " % string.join(filters, ",")

        if self._window:
            args += "-wid %s " % hex(self._window.get_id())
            args += "-display %s " % self._window.get_display().get_string()
            args += "-input conf=%s " % keyfile

        if user_args:
            if isinstance(user_args, (list, tuple)):
                user_args = " ".join(user_args)
            args += "%s " % user_args
        if file:
            args += "\"%s\"" % file

        self._spawn(args)
        self._state = STATE_OPENING


    def _slave_cmd(self, cmd):
        if not self.is_alive():
            return False

        if self._debug >= 1:
            print "SLAVE:", cmd
        self._process.write(cmd + "\n")


    def _exited(self, exitcode):
        if self._state in (STATE_PLAYING, STATE_PAUSED):
            self.signals["end"].emit()

        self._state = STATE_NOT_RUNNING
        self.signals["quit"].emit()
        if exitcode != 0:
            raise MPlayerExitError, (exitcode, self._last_line)


    def is_alive(self):
        return self._process and self._process.is_alive()

    def open(self, mrl, user_args = None):
        schemes = self.get_supported_schemes()
        scheme, path = parse_mrl(mrl)

        if scheme not in schemes:
            raise ValueError, "Unsupported mrl scheme '%s'" % scheme

        self._file_args = []
        if scheme in ("file", "fifo"):
            self._file = path
        elif scheme == "dvd":
            file, title = re.search("(.*?)(\/\d+)?$", path).groups()
            if file not in ("/", "//"):
                if not os.path.isfile(file):
                    raise ValueError, "Invalid ISO file: %s" % file
                self._file_args.append("-dvd-device \"%s\"" % file)

            self._file = "dvd://"
            if title:
                self._file += title[1:]
        else:
            self._file = mrl

        if user_args:
            self._file_args.append(user_args)
        
        self.signals["open"].emit()



    def play(self):
        state = self.get_state()
        if state == STATE_PAUSED:
            self._slave_cmd("pause")
        elif state == STATE_IDLE:
            # FIXME: DVD ISO files will require a restart (for -dvd-device)
            #self._slave_cmd("loadfile \"%s\"" % self._file)
            return

        if state != STATE_NOT_RUNNING:
            return

        if self._window == None:
            # Use the user specified size, or some sensible default.
            win_size = self._size or (640, 480)
            self._window = display.X11Window(size = win_size, title = "MPlayer Window")
            # TODO: get from config value
            self._window.set_cursor_hide_timeout(0.5)


        if not self._mp_info:
            # We're probably waiting for _get_mplayer_info() to finish; set
            # state so that _handle_mp_info() will call _start().  There's no
            # race condition here if we're currently in the main thread,
            # because _handle_mp_info() is guaranteed to be called in the
            # main thread.
            self._state = STATE_OPENING
            self._state_data = self._file, self._file_args
            return False

        self._start(self._file, self._file_args)
        return True


    def pause(self):
        if self.get_state() == STATE_PLAYING:
            self._slave_cmd("pause")

    def pause_toggle(self):
        if self.get_state() == STATE_PAUSED:
            self.play()
        else:       
            self.pause()


    def seek_relative(self, offset):
        self._slave_cmd("seek %f 0" % offset)

    def seek_absolute(self, position):
        self._slave_cmd("seek %f 2" % position)

    def seek_percentage(self, percent):
        self._slave_cmd("seek %f 1" % percent)

    def stop(self):
        #self._slave_cmd("pt_step + 1")
        #self._state = STATE_IDLE
        self.die()
        self._state = STATE_NOT_RUNNING

    def _end_child(self):
        self._slave_cmd("quit")
        # Could be paused, try sending again.
        self._slave_cmd("quit")

    def die(self):
        if self._process:
            self._process.stop()

    def get_vo_size(self):
        return self._vo_size

    def get_position(self):
        return self._position

    def get_info(self):
        return self._file_info

    def prepend_filter(self, filter):
        self._filters_pre.append(filter)

    def append_filter(self, filter):
        self._filters_add.append(filter)

    def get_filters(self):
        return self._filters_pre + self._filters_add

    def remove_filter(self, filter):
        for l in (self._filters_pre, self._filters_add):
            if filter in l:
                l.remove(filter)

    def osd_update(self, alpha = None, visible = None, invalid_regions = None):
        cmd = []
        if alpha != None:
            cmd.append("alpha=%d" % alpha)
        if visible != None:
            cmd.append("visible=%d" % int(visible))
        if invalid_regions:
            for (x, y, w, h) in invalid_regions:
                cmd.append("invalidate=%d:%d:%d:%d" % (x, y, w, h))
        self._slave_cmd("overlay %s" % ",".join(cmd))
        self._overlay_set_lock(BUFFER_LOCKED)


    def osd_can_update(self):
        if not self._overlay_shmem:
            return False

        try:
            if ord(self._overlay_shmem.read(1)) == BUFFER_UNLOCKED:
                return True
        except:
            self._overlay_shmem = None

        return False


    def _overlay_set_lock(self, byte):
        try:
            if self._overlay_shmem and self._overlay_shmem.attached:
                self._overlay_shmem.write(chr(byte))
        except shm.error:
            self._overlay_shmem = None


    def _check_new_frame(self):
        if not self._outbuf_shmem:
            return

        try:
            lock, width, height, aspect = struct.unpack("hhhd", self._outbuf_shmem.read(16))
        except:
            self._outbuf_shmem = None
            return

        if lock & BUFFER_UNLOCKED:
            return

        if width > 0 and height > 0 and aspect > 0:
            self.signals["frame"].emit(width, height, aspect, self._outbuf_shmem.addr + 16, "yv12")

    def unlock_frame_buffer(self):
        try:
            self._outbuf_shmem.write(chr(BUFFER_UNLOCKED))
        except shm.error:
            self._outbuf_shmem = None


    def set_frame_output_mode(self, vo = None, notify = None, size = None):
        if vo != None:
            self._cur_outbuf_mode[0] = vo
        if notify != None:
            self._cur_outbuf_mode[1] = notify
            if notify:
                self._check_new_frame_timer.start(0.01)
            else:
                self._check_new_frame_timer.stop()
        if size != None:
            self._cur_outbuf_mode[2] = size

        if not self.is_alive():
            return

        mode = { (False, False): 0, (True, False): 1,
                 (False, True): 2, (True, True): 3 }[tuple(self._cur_outbuf_mode[:2])]

        size = self._cur_outbuf_mode[2]
        if size == None:
            self._slave_cmd("outbuf %d" % mode)
        else:
            self._slave_cmd("outbuf %d %d %d" % (mode, size[0], size[1]))

    def nav_command(self, input):
        return False


    def get_player_id(self):
        return "mplayer"




def get_capabilities():
    capabilities = [CAP_VIDEO, CAP_AUDIO, CAP_DVD, CAP_VARIABLE_SPEED]
    mp_cmd = kaa.utils.which("mplayer")
    info = _get_mplayer_info(mp_cmd)
    if not info:
        return None, None, None

    if "overlay" in info["video_filters"]:
        capabilities.append(CAP_OSD)
    if "outbuf" in info["video_filters"]:
        capabilities.append(CAP_CANVAS)

    schemes = ["file", "vcd", "cdda", "cue", "tivo", "http", "mms", "rtp",
                "rtsp", "ftp", "udp", "sdp", "dvd", "fifo"]

    exts = ["avi", "wmv", "mkv", "asf", "mov"]  # FIXME: complete.
    return capabilities, schemes, exts

register_player("mplayer", MPlayer, get_capabilities)
